$(document).ready(function() {
  $("#upload-form").uploadprogress({redirect_url: '/'});
});

