from django.apps import AppConfig


class StocksappConfig(AppConfig):
    name = 'stocksapp'
